<?php
 
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'guest';
 
$koneksi = mysqli_connect($hostname, $username, $password, $database); 
 
?>