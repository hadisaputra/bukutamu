<?php
include_once("koneksi.php");

session_start();
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
    $foto=$_POST['foto'];
	$nama=$_POST['nama'];
    $jk=$_POST['jk'];
	$alamat=$_POST['alamat'];
    $keperluan=$_POST['keperluan'];
    $ponsel=$_POST['ponsel'];
    $tanggal=$_POST['tanggal'];
    $lembaga=$_POST['lembaga'];

	$result = mysqli_query($koneksi, "UPDATE datatamu SET foto='$foto', nama='$nama', jk='$jk', alamat='$alamat', keperluan='$keperluan', ponsel='$ponsel', tanggal='$tanggal', lembaga='$lembaga' WHERE id=$id");
	header("Location: list.php");
}
?>
<?php
$id = $_GET['id'];
$result = mysqli_query($koneksi, "SELECT * FROM datatamu WHERE id=$id");
$data = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>PA SRL</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
 <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center">
          <div class="sidebar-brand-icon rotate-n-15">
             <i class="fas fa-book"></i>
          </div>
        <div class="sidebar-brand-text mx-3">Buku Tamu<sup></sup></div>
      </a>

       <!-- Divider -->
       <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span style="font-size:20px">Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Data
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span style="font-size:20px">Tamu</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="list.php">Daftar Tamu</a>
                    </div>
                </div>
            </li>

            
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Tentang
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-landmark"></i>
                    <span style="font-size:20px">Profil</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="profil.php">Profil Pengadilan</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <marquee><font face="Cambria" color="blue"><h1>Selamat Datang di Pengadilan Agama Sarolangun, <?php echo $_SESSION['username']; ?> !</h1></marquee><br>
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>



                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <span class="mr-2 d-none d-lg-inline text-dark large">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-black"></i>
                                <?php echo $_SESSION['username']; ?></span>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="profilpengguna.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profil Pengguna
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Guest Book</h1>
                    <div class="row">

                        <div class="col-lg-12">

                            <!-- Circle Buttons -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">EDIT DATA TAMU</h6>
                                </div>
                                <div class="card-body" style="background-color:#B0E0E6">
                                    
            <form name="update_user" method="post" action="edit.php" style="background-color:#B0E0E6">
                		<div class="form-group">
                            <label class="form-group">Foto</label>
                            <input type="file" class="file" name="foto" id="foto">
                        </div>

                        <div class="form-group">
                            <label class="form-group">Nama</label>
                            <input type="text" class="form-control" name="nama" id="nama" value="<?php echo $data['nama'];?>">
                        </div>

                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="jk" id="jk1" checked="" value="Laki-laki">
                                <label>Laki-laki </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="jk" id="jk2" value="Perempuan">
                                <label>Perempuan</label>
                            </div>
                        </div> 

                		<div class="form-group">
                			<label class="form-group">Alamat</label>
                			<input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo $data['alamat'];?>">
                		</div>
                        <div class="form-group">
                            <label class="form-group">Keperluan</label>
                            <input type="text" class="form-control" name="keperluan" id="keperluan" value="<?php echo $data['keperluan'];?>">
                        </div>
                        <div class="form-group">
                            <label class="form-group">Nomor Ponsel</label>
                            <input type="text" class="form-control" name="ponsel" id="ponsel" value="<?php echo $data['ponsel'];?>">
                        </div>
                        <div class="form-group">
                            <label class="form-group">Tanggal</label>
                            <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?php echo $data['tanggal'];?>">
                        </div>

                        <div class="form-group">
                            <label class="form-group">Lembaga</label>
                            <input type="text" class="form-control" name="lembaga" id="lembaga"  value="<?php echo $data['lembaga'];?>">
                        </div>
                			
                		<div class="col-12">
                			<input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                			<input type="submit" name="update" value="Update"></td>
                		</div>
                	</form>
                                </div>
                            </div>

                        </div>

                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Elvira Dwi 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalLabel">Apakah Anda yakin?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik tombol "Logout" jika Anda ingin keluar</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-danger" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>