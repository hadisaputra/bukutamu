<?php
 
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'guest';
 
$koneksi = mysqli_connect($hostname, $username, $password, $database); 

//set random name for the image, used time() for uniqueness
//require_once('db.php'); 
$filename =  time() . '.jpg';
$filepath = 'img/';
if(!is_dir($filepath))
	mkdir($filepath);
if(isset($_FILES['webcam'])){	
	move_uploaded_file($_FILES['webcam']['tmp_name'], $filepath.$filename);
	echo $filepath.$filename;
}
?>
