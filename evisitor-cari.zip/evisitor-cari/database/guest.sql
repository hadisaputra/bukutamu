/*
SQLyog Ultimate v10.3 
MySQL - 5.5.5-10.1.38-MariaDB : Database - guest
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`guest` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `guest`;

/*Table structure for table `datatamu` */

DROP TABLE IF EXISTS `datatamu`;

CREATE TABLE `datatamu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) NOT NULL,
  `nama` text NOT NULL,
  `jk` text NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `keperluan` text NOT NULL,
  `ponsel` text NOT NULL,
  `tanggal` date NOT NULL,
  `lembaga` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4;

/*Data for the table `datatamu` */

insert  into `datatamu`(`id`,`foto`,`nama`,`jk`,`alamat`,`keperluan`,`ponsel`,`tanggal`,`lembaga`) values (119,'','marwan','Laki-laki','cempaka putih','kunjungan','0852111412522','2021-10-08','-'),(120,'','marwan','Laki-laki','cpk','poligami','0211144424','2021-10-08','-'),(121,'','iis','Perempuan','sepancar','mengantar surat','082375328991','2021-01-02','-'),(122,'','iis','Perempuan','sepancar','mengantar surat','082375328991','2021-03-03','-'),(123,'','iis','Perempuan','sepancar','mengantar surat','082375328991','2021-10-15','-'),(124,'','iis','Perempuan','sepancar','mengantar surat','082375328991','2021-03-05','-'),(125,'','iis','Perempuan','sepancar','mengantar surat','082375328991','2021-10-20','-');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` text NOT NULL,
  `username` text NOT NULL,
  `password` varchar(30) NOT NULL,
  `level` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `user` */

insert  into `user`(`id`,`nama`,`username`,`password`,`level`) values (1,'admin','admin','admin','admin\r\n');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
