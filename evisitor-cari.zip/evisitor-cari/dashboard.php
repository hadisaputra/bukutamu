<?php
include_once("koneksi.php");

session_start();
if($_SESSION['status']!="login"){
header("location:index.php?pesan=belum_login");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>PA BTA</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <script type="text/javascript" src="chartjs/Chart.js"></script>
    <style type="text/css">
        table{margin: 0px auto;}
    </style>
</head>

<body id="page-top">

    <?php

       // $count = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu"));      
       $jumlah1 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 1 AND YEAR(tanggal) = 2021"));
       $jumlah2 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 2 AND YEAR(tanggal) = 2021"));
       $jumlah3 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 3 AND YEAR(tanggal) = 2021"));
       $jumlah4 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 4 AND YEAR(tanggal) = 2021"));
       $jumlah5 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 5 AND YEAR(tanggal) = 2021"));
       $jumlah6 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 6 AND YEAR(tanggal) = 2021"));
       $jumlah7 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 7 AND YEAR(tanggal) = 2021"));
       $jumlah8 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 8 AND YEAR(tanggal) = 2021"));
       $jumlah9 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 9 AND YEAR(tanggal) = 2021"));
       $jumlah10 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 10 AND YEAR(tanggal) = 2021"));
       $jumlah11 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 11 AND YEAR(tanggal) = 2021"));
       $jumlah12 =  mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM datatamu WHERE MONTH(tanggal) = 12 AND YEAR(tanggal) = 2021"));
    ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Buku Tamu <sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span style="font-size:20px">Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Data
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span style="font-size:20px">Tamu</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="list.php">Daftar Tamu</a>
                    </div>
                </div>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Tentang
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-landmark"></i>
                    <span  style="font-size:20px">Profil</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                       <a class="collapse-item" href="profil.php">Profil Pengadilan</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-gradient-light topbar mb-4 static-top shadow">
                <marquee><font face="Cambria" color="blue"><h1>Selamat Datang di Pengadilan Agama Baturaja, <?php echo $_SESSION['username']; ?> !</h1></marquee><br>
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <span class="mr-2 d-none d-lg-inline text-dark large">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-black"></i>
                                <?php echo $_SESSION['username']; ?></span>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="profilpengguna.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-dark"></i>
                                    Profil Pengguna
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-dark"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content 
                <div class="container-fluid" style="background-image: linear-gradient(#B0E0E6, white)">
                    <!-- Page Heading 
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mt-3 mb-0 text-dark">Jumlah Tamu Per 2021</h1>
                    </div>

                    <!-- Content Row style="background:rgb(255, 206, 86)
                    
                    <div class="row">
                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Januari</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah1.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Februari</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah2.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Maret</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah3.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                April</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah4.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Mei</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah5.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Juni</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah6.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Juli</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah7.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Agustus</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah8.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                September</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah9.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Oktober</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah10.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                November</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah11.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2 mb-4">
                            <div class="card border-left-dark bg-gradient-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-sm font-weight-bold text-light text-uppercase mb-1">
                                                Desember</div>
                                            <div class="h5 mb-0 font-weight-bold text-light"><?php echo '<h5> '.$jumlah12.' Tamu</h3>'; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-lg text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Content Row -->
					

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">

                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Grafik Batang</h6>
                                </div>
                               
                                <div style="width: 500px; margin: 0px auto;" >
                                    <canvas id="barChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Grafik Lingkaran</h6>
                                </div>

                                <div style="width: 500px; margin: 0px auto;">
                                    <canvas id="doughnutChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; PA Baturaja 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Apakah Anda yakin?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik tombol "Logout" jika Anda ingin keluar</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-danger" href="index.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>


  <script>
        var xValues = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
        var ctx = document.getElementById("barChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: xValues,
                datasets: [{
                    label: '',
                    data: [
                    <?php echo $jumlah1; ?>, 
                    <?php echo $jumlah2; ?>, 
                    <?php echo $jumlah3; ?>, 
                    <?php echo $jumlah4; ?>,
                    <?php echo $jumlah5; ?>, 
                    <?php echo $jumlah6; ?>, 
                    <?php echo $jumlah7; ?>, 
                    <?php echo $jumlah8; ?>,
                    <?php echo $jumlah9; ?>, 
                    <?php echo $jumlah10; ?>, 
                    <?php echo $jumlah11; ?>, 
                    <?php echo $jumlah12; ?>,
                    ],
                    backgroundColor: [
                    'rgba(255, 0, 0, 1)',
                    'rgba(255, 140, 0, 1)',
                    'rgba(127, 255, 0, 1)',
                    'rgba(0, 191, 255, 1)',
                    'rgba(153, 50, 204, 1)',
                    'rgba(255, 20, 147, 1)',
                    'rgba(255, 215, 0, 1)',
                    'rgba(211, 211, 211, 1)',
                    'rgba(255, 222, 173, 1)',  
                    'rgba(0, 255, 86, 0.2)',
                    'rgba(139, 69, 19, 1 )',                  
                    'rgba(0, 0, 205, 1)'
                    ],
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
        });


        var ctx = document.getElementById("doughnutChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
                datasets: [{
                    label: '',
                    data: [
                    <?php echo $jumlah1; ?>, 
                    <?php echo $jumlah2; ?>, 
                    <?php echo $jumlah3; ?>, 
                    <?php echo $jumlah4; ?>,
                    <?php echo $jumlah5; ?>, 
                    <?php echo $jumlah6; ?>, 
                    <?php echo $jumlah7; ?>, 
                    <?php echo $jumlah8; ?>,
                    <?php echo $jumlah9; ?>, 
                    <?php echo $jumlah10; ?>, 
                    <?php echo $jumlah11; ?>, 
                    <?php echo $jumlah12; ?>,
                    ],
                    backgroundColor: [
                    'rgba(255, 0, 0, 1)',
                    'rgba(255, 140, 0, 1)',
                    'rgba(127, 255, 0, 1)',
                    'rgba(0, 191, 255, 1)',
                    'rgba(153, 50, 204, 1)',
                    'rgba(255, 20, 147, 1)',
                    'rgba(255, 255, 0, 1)',
                    'rgba(211, 211, 211, 1)',
                    'rgba(255, 222, 173, 1)',  
                    'rgba(0, 255, 86, 0.2)',
                    'rgba(139, 69, 19, 1 )',                  
                    'rgba(0, 0, 205, 1)'
                    ],
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
        });
    </script>