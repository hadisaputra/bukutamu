<?php
include_once("koneksi.php");

session_start();
if($_SESSION['status']!="login"){
header("location:index.php?pesan=belum_login");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>Data Tables</title>

    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.1.0.js"></script>
    <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 

     <!--
    <link rel="stylesheet" href="./asset/bootstrap.min.css" />
    <link rel="stylesheet" href="./asset/dataTables.bootstrap.min.css" />
    <script src="./asset/jquery-3.1.0.js"></script>
    <script src="./asset/jquery.dataTables.min.js"></script>
    <script src="./asset/dataTables.bootstrap.min.js"></script> -->


  </head>
  <body>


    <table id="tabel-data" class="table table-striped table-bordered" width="100%" cellspacing="0">
    
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Alamat</th>
                                            <th>Keperluan</th>
                                            <th>Np. HP</th>
                                            <th>Tanggal</th>
                                            <th>Lembaga</th>
                                            <th>Aksi</th>

                                            
                                        </tr>
                                    </thead>
                                    
                              

                                    <tbody>
                                    <?php         
                                        include("koneksi.php");                    
                                        $hasil = mysqli_query($koneksi, "SELECT * FROM datatamu ORDER BY tanggal DESC") or die(mysql_error());
                                        $nomor = 1;
                                        while($data = mysqli_fetch_array($hasil)){
                                    ?>
                                        <tr>
                                            <td><?php echo $nomor++; ?></td>
                                            <td><?php echo $data['nama']; ?></td>
                                            <td><?php echo $data['jk']; ?></td>
                                            <td><?php echo $data['alamat']; ?></td>
                                            <td><?php echo $data['keperluan']; ?></td>
                                            <td><?php echo $data['ponsel']; ?></td>
                                            <td><?php echo $data['tanggal']; ?></td>
                                            <td><?php echo $data['lembaga']; ?></td>
                                            <td><a class="btn btn-info btn-circle btn-sm" href="edit.php?id=<?php echo $data['id']; ?>"><i class="fas fa-edit"></i></a></a> 
                                            <a class="btn btn-danger btn-circle btn-sm" href="#" data-href="delete.php?id=<?php echo $data['id']; ?>" data-toggle="modal" data-target="#confirm-delete"><i class="fas fa-trash"></i></a></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>

    <script>
      $(document).ready(function () {
        $("#tabel-data").DataTable();
      });
    </script>
  </body>
</html>
